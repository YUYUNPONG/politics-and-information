## R_資料科學程式設計

### week_1

- course_1
    - practice_1.R
    - practice_2.R
    - practice_3.R
- task_1_question
    - hw_1_question.R
    
- week_1任務
    - 建立個人`Github帳號`
    - 建立本課程專用`Repository`
    - 在該 repository 當中上傳建立一命名為 `week_1(or task_1, hw_1)`的資料夾
    - 於`該資料夾`中，上傳本周練習的`成果檔案(ex: hw_1_answers.R)`
    - 內容不限定要完成多少題，只是希望同學們能在稍微熟悉 R 語言後，進行一些練習
    - 於 2018/9/20 課堂前上傳即可。
