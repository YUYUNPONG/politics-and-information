## R_資料科學程式設計

### week_5

- course_5
    - example_1_text_mining.R(tentative)
        - Term to Document Matrix, tf-idf, pca, k-means
    - [shiny-examples-master](https://github.com/rstudio/shiny-examples) (之後會寫shiny app作業，可先看)
        - You could learn with **those examples** online by viewing `https://gallery.shinyapps.io/案例檔名`
            - EX: https://gallery.shinyapps.io/001-hello
        - check **[shiny gallery](https://shiny.rstudio.com/gallery/)** to inspire your ideas!
        - check **[shiny widget gallery](https://shiny.rstudio.com/gallery/widget-gallery.html)** to meet widgets! 

- week_5任務
    - 建立一命名為 week_5(or task_5, hw_5)的資料夾。
    - 完成一份_________-上傳至資料夾中，須繳交兩份檔案[.Rmd, .html)]。
