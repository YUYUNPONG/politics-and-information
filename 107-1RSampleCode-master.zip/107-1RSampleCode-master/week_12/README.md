### [課程投影片](https://ppt.cc/fxQ79x)

## Data Details
1. 英文新聞資料：path/news.txt
2. 使用 NLTK 完成 NER 範例程式：NER.ipynb

## 本週任務
將沒有做過 NER 的資料，加入 NER，再銜接以前做過的方法，看看有甚麼不同。
