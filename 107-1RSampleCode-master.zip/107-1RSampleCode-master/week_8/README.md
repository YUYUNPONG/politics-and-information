
## R_資料科學程式設計

### week_7

- course_7
  - rough_linear_regression_example.R
  - rough_svm_example.R
  - dataset
    - GamePoints_Data.csv
