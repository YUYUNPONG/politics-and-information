## R_資料科學程式設計

### week_6&7&8

- week_6&7&8任務
    - 6 & 7 & 8 三週合併作業，一起打分數 15%
    - [仿造 Kaggle 模式完成一份分析報告](http://blog.kaggle.com/2017/09/21/instacart-market-basket-analysis-winners-interview-2nd-place-kazuki-onodera/)
    - [並使用 Shiny 呈現 Demo 結果](https://lanw868.shinyapps.io/poetry_analysis/)