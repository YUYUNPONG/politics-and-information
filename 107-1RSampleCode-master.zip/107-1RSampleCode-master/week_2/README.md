## R_資料科學程式設計

### week_2

- course_2
    - practice_1.R
    - practice_1_answer.R
    - practice_2.R
    - practice_2_answer.R
    - practice_3.R
    - crawler_example

- hw_2
    - hw_2_crawler_example
        - PChomeRCrawler.html
        - PChomeRCrawler.r
        - PChomeRCrawler.Rmd ([作業參考](https://howardchao.github.io/CSX_RProject_Spring_2018/week_2/task_2_self_practice/R_crawler_rvest_practice.html))
    - hw_2_extra_OOXX_game.R

- week_2任務
    - 建立一命名為 `week_2(or task_2, hw_2)`的資料夾。
    - 完成一支網站爬蟲上傳至資料夾中，繳交三種類型檔案(.R, .Rmd, .html)。 
    - 挑戰作業：完成 OOXX遊戲！！(有時間再寫，完成可以跟大家分享)
    - 於 2018/9/26 晚上12點前。
